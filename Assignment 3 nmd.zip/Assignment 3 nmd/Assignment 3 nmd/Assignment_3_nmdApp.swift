//
//  Assignment_3_nmdApp.swift
//  Assignment 3 nmd
//
//  Created by MacBook Air on 08.01.2025.
//

import SwiftUI

@main
struct Assignment_3_nmdApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
