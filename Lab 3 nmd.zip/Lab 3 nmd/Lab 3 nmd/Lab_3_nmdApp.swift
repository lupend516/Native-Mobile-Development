//
//  Lab_3_nmdApp.swift
//  Lab 3 nmd
//
//  Created by MacBook Air on 16.01.2025.
//

import SwiftUI

@main
struct Lab_3_nmdApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
