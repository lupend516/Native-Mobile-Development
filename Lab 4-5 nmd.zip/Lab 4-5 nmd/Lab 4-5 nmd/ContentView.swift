import SwiftUI

struct ContentView: View {
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                Group {
                    Text("Task 1: AnimeCharacter")
                        .font(.headline)
                    Text(hero.introduce())
                    Text(villain.introduce())
                    
                    Divider()
                    
                    Text("Task 2: Weapon")
                        .font(.headline)
                    Text(sword.use())
                    
                    Divider()
                    
                    Text("Task 3: CharacterClass")
                        .font(.headline)
                    Text(warrior.description())
                    Text(mage.description())
                }
                
                Divider()
                
                Group {
                    Text("Task 4: HumanCharacter")
                        .font(.headline)
                    Text(humanHero.introduce())
                }
            }
            .padding()
        }
    }
}

class AnimeCharacter {
    var name: String
    var powerLevel: Int
    var isHero: Bool

    init(name: String, powerLevel: Int, isHero: Bool) {
        self.name = name
        self.powerLevel = powerLevel
        self.isHero = isHero
    }

    func introduce() -> String {
        let role = isHero ? "Hero" : "Villain"
        return "I am \(name), a \(role) with power level \(powerLevel)!"
    }
}

struct Weapon {
    var name: String
    var damage: Int

    func use() -> String {
        return "\(name) deals \(damage) damage!"
    }
}

enum CharacterClass {
    case warrior(armor: Int)
    case mage(mana: Int)

    func description() -> String {
        switch self {
        case .warrior(let armor):
            return "Warrior with armor value \(armor)."
        case .mage(let mana):
            return "Mage with mana value \(mana)."
        }
    }
}

class HumanCharacter: AnimeCharacter {
    var weapon: Weapon?

    override func introduce() -> String {
        let weaponInfo = weapon != nil ? "wielding \(weapon!.name)" : "unarmed"
        let role = isHero ? "Hero" : "Villain"
        return "I am \(name), a \(role) with power level \(powerLevel), \(weaponInfo)!"
    }
}

let hero = AnimeCharacter(name: "Saitama", powerLevel: 1000, isHero: true)
let villain = AnimeCharacter(name: "Garou", powerLevel: 950, isHero: false)
let sword = Weapon(name: "Excalibur", damage: 500)
let warrior = CharacterClass.warrior(armor: 200)
let mage = CharacterClass.mage(mana: 300)
let humanHero: HumanCharacter = {
    let human = HumanCharacter(name: "Eren", powerLevel: 900, isHero: true)
    human.weapon = Weapon(name: "ODM Gear", damage: 300)
    return human
}()

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
