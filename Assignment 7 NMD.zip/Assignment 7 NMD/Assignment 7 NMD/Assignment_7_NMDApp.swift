//
//  Assignment_7_NMDApp.swift
//  Assignment 7 NMD
//
//  Created by MacBook Air on 27.01.2025.
//

import SwiftUI

@main
struct Assignment_7_NMDApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
