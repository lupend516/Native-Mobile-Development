import SwiftUI

struct ContentView: View {
    @State private var hours = 0
    @State private var minutes = 0
    @State private var seconds = 0
    
    @State private var remainingTime = 0
    @State private var timerActive = false
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    
    var body: some View {
        VStack(spacing: 30) {
            Text("Custom Timer")
                .font(.largeTitle)
                .padding(.top)
            
            Text(timeString(from: remainingTime))
                .font(.system(size: 48, weight: .bold, design: .monospaced))
                .foregroundColor(remainingTime == 0 ? .red : .primary)
            
            HStack(spacing: 20) {
                VStack {
                    Text("Hours")
                        .font(.headline)
                        .foregroundColor(.gray)
                    StepperView(value: $hours, range: 0...23)
                }
                
                VStack {
                    Text("Minutes")
                        .font(.headline)
                        .foregroundColor(.gray)
                    StepperView(value: $minutes, range: 0...59)
                }
                
                VStack {
                    Text("Seconds")
                        .font(.headline)
                        .foregroundColor(.gray)
                    StepperView(value: $seconds, range: 0...59)
                }
            }
            
            HStack(spacing: 20) {
                Button(timerActive ? "Stop" : "Start") {
                    if timerActive {
                        timerActive = false
                    } else {
                        remainingTime = hours * 3600 + minutes * 60 + seconds
                        if remainingTime > 0 {
                            timerActive = true
                        }
                    }
                }
                .font(.title2)
                .padding()
                .frame(maxWidth: .infinity)
                .background(timerActive ? Color.red : Color.green)
                .foregroundColor(.white)
                .cornerRadius(10)
                
                Button("Reset") {
                    timerActive = false
                    remainingTime = 0
                    hours = 0
                    minutes = 0
                    seconds = 0
                }
                .font(.title2)
                .padding()
                .frame(maxWidth: .infinity)
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
            }
            .padding(.horizontal)
        }
        .padding()
        .onReceive(timer) { _ in
            if timerActive && remainingTime > 0 {
                remainingTime -= 1
            } else if remainingTime == 0 {
                timerActive = false
            }
        }
    }
    

    func timeString(from seconds: Int) -> String {
        let h = seconds / 3600
        let m = (seconds % 3600) / 60
        let s = seconds % 60
        return String(format: "%02d:%02d:%02d", h, m, s)
    }
}

struct StepperView: View {
    @Binding var value: Int
    let range: ClosedRange<Int>
    
    var body: some View {
        HStack {
            Button(action: {
                if value < range.upperBound {
                    value += 1
                }
            }) {
                Image(systemName: "arrowtriangle.up.fill")
                    .resizable()
                    .frame(width: 20, height: 20)
                    .foregroundColor(.blue)
            }
            
            Text("\(value)")
                .font(.system(size: 36))
                .frame(width: 60)
            
            Button(action: {
                if value > range.lowerBound {
                    value -= 1
                }
            }) {
                Image(systemName: "arrowtriangle.down.fill")
                    .resizable()
                    .frame(width: 20, height: 20)
                    .foregroundColor(.blue)
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
