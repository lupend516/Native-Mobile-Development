//
//  Final_p1App.swift
//  Final p1
//
//  Created by MacBook Air on 10.02.2025.
//

import SwiftUI

@main
struct Final_p1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
