import SwiftUI

struct AddTaskView: View {
    @Binding var tasks: [String]
    @Environment(\.presentationMode) var presentationMode
    @State private var taskText: String = ""
    
    var body: some View {
        NavigationView {
            VStack {
                TextField("Введите задачу", text: $taskText)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                
                Button(action: {
                    if !taskText.isEmpty {
                        tasks.append(taskText)
                        saveTasks()
                        presentationMode.wrappedValue.dismiss()
                    }
                }) {
                    Text("Сохранить")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .padding()
                }
                
                Spacer()
            }
            .navigationTitle("Добавить задачу")
        }
    }
    
    func saveTasks() {
        UserDefaults.standard.set(tasks, forKey: "savedTasks")
    }
}
