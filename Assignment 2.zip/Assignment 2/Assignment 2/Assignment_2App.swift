//
//  Assignment_2App.swift
//  Assignment 2
//
//  Created by MacBook Air on 26.12.2024.
//

import SwiftUI

@main
struct Assignment_2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
