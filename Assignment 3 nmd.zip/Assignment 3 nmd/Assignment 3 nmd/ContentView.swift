import SwiftUI

enum CharacterClass {
    case warrior(armor: Int)
    case mage(mana: Int)
}

class RPGCharacter {
    var name: String
    var health: Int
    var characterClass: CharacterClass
    
    init(name: String, health: Int, characterClass: CharacterClass) {
        self.name = name
        self.health = health
        self.characterClass = characterClass
    }
    
    func attack(opponent: RPGCharacter) {
        switch characterClass {
        case .warrior(let armor):
            let damage = armor / 2
            opponent.health -= damage
            print("\(name) attacks with a sword for \(damage) damage.")
        case .mage(let mana):
            let damage = mana
            opponent.health -= damage
            print("\(name) casts a spell for \(damage) damage.")
        }
    }
}

func fight(_ char1: RPGCharacter, _ char2: RPGCharacter) -> String {
    var battleLog = "The battle begins between \(char1.name) and \(char2.name)!\n"
    
    while char1.health > 0 && char2.health > 0 {
        char1.attack(opponent: char2)
        battleLog += "\(char1.name) attacks \(char2.name) (Remaining health: \(char2.health))\n"
        
        if char2.health > 0 {
            char2.attack(opponent: char1)
            battleLog += "\(char2.name) attacks \(char1.name) (Remaining health: \(char1.health))\n"
        }
    }
    
    if char1.health > 0 {
        battleLog += "\(char1.name) wins!\n"
    } else {
        battleLog += "\(char2.name) wins!\n"
    }
    return battleLog
}

struct ContentView: View {
    @State private var battleLog: String = ""
    @State private var char1Name: String = ""
    @State private var char2Name: String = ""
    @State private var fightStarted: Bool = false
    
    var body: some View {
        VStack(spacing: 20) {
            Text("RPG Battle Simulator")
                .font(.largeTitle)
                .padding()
            
         
            TextField("Enter Warrior Name", text: $char1Name)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
            TextField("Enter Mage Name", text: $char2Name)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
            Button("Start Battle") {
                guard !char1Name.isEmpty, !char2Name.isEmpty else {
                    battleLog = "Please enter both character names!"
                    return
                }
                
                let warrior = RPGCharacter(name: char1Name, health: 100, characterClass: .warrior(armor: 50))
                let mage = RPGCharacter(name: char2Name, health: 80, characterClass: .mage(mana: 40))
                
                
                battleLog = fight(warrior, mage)
                fightStarted = true
            }
            .padding()
            .disabled(fightStarted)
            
           
            Button("New Fight") {
                char1Name = ""
                char2Name = ""
                battleLog = ""
                fightStarted = false
            }
            .padding()
            .disabled(!fightStarted)
            
            ScrollView {
                Text(battleLog)
                    .padding()
            }
            .frame(maxHeight: 300)
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
