//
//  Lab_4_5_nmdApp.swift
//  Lab 4-5 nmd
//
//  Created by MacBook Air on 16.01.2025.
//

import SwiftUI

@main
struct Lab_4_5_nmdApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
