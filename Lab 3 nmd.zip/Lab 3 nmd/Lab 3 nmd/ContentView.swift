import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            List {
                NavigationLink("Part 1: Functions", destination: Part1View())
                NavigationLink("Part 2: Collections", destination: Part2View())
                NavigationLink("Part 3: Optionals", destination: Part3View())
            }
            .navigationTitle("Laboratory Work 3")
        }
    }
}

struct Part1View: View {
    @State private var functionResult = ""
    @State private var closureResult: [Int] = []

    var body: some View {
        VStack(spacing: 20) {
            Text("Part 1: Working with Functions")
                .font(.headline)

            Button("Call Function addNumbers") {
                functionResult = "Sum: \(addNumbers(3, 5))"
            }
            Text(functionResult)

            Button("Apply Closure to Array") {
                let array = [1, 2, 3, 4, 5]
                let closure: (Int) -> Int = { $0 * 2 }
                closureResult = applyClosureToArray(array, closure)
            }
            Text("Transformed Array: \(String(describing: closureResult))")

            Spacer()
        }
        .padding()
    }

    func addNumbers(_ a: Int, _ b: Int) -> Int {
        return a + b
    }

    func applyClosureToArray(_ array: [Int], _ closure: (Int) -> Int) -> [Int] {
        return array.map { closure($0) }
    }
}

struct Part2View: View {
    @State private var array: [String] = ["Apple", "Orange", "Banana"]
    @State private var dictionary: [String: Int] = ["Alice": 25, "Bob": 30]

    var body: some View {
        VStack(spacing: 20) {
            Text("Part 2: Working with Collections")
                .font(.headline)

            Button("Manipulate Array") {
                array.append("Grape")
                array.remove(at: 1)
                array.sort()
            }
            Text("Array: \(String(describing: array))")

            Button("Manipulate Dictionary") {
                dictionary["Charlie"] = 35
                dictionary["Alice"] = 26
                dictionary.removeValue(forKey: "Bob")
            }
            Text("Dictionary: \(String(describing: dictionary))")

            Spacer()
        }
        .padding()
    }
}

struct Part3View: View {
    @State private var optionalResult = ""
    @State private var sumResult = ""

    var body: some View {
        VStack(spacing: 20) {
            Text("Part 3: Working with Optionals")
                .font(.headline)

            Button("Describe Optional Number") {
                optionalResult = describeOptionalNumber(10)
            }
            Text(optionalResult)

            Button("Sum of Two Optionals") {
                sumResult = sumOfTwoOptionalNumbers(10, 5)
            }
            Text(sumResult)

            Spacer()
        }
        .padding()
    }

    func describeOptionalNumber(_ number: Int?) -> String {
        if let value = number {
            return "Number: \(value)"
        } else {
            return "Number is missing, default value is 1"
        }
    }

    func sumOfTwoOptionalNumbers(_ a: Int?, _ b: Int?) -> String {
        let defaultA = a ?? 1
        let defaultB = b ?? 1
        let sum = defaultA + defaultB

        return "Sum: \(sum)"
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
