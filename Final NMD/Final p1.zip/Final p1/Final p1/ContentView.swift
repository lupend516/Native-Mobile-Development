import SwiftUI

// Протокол для управления историей конверсий
protocol HistoryManager {
    func addEntry(_ entry: (String, String))
    func clearHistory()
}

// Реализация протокола в виде ObservableObject
class HistoryManagerImpl: ObservableObject, HistoryManager {
    @Published var history: [(String, String)] = []
    
    func addEntry(_ entry: (String, String)) {
        withAnimation {
            history.append(entry)
        }
    }
    
    func clearHistory() {
        withAnimation {
            history.removeAll()
        }
    }
}

// Функция для локализации строк по ключу и выбранному языку
func localized(_ key: String, lang: String) -> String {
    let translations: [String: [String: String]] = [
        "Currency Converter": ["en": "Currency Converter", "ru": "Конвертер валют", "kk": "Валюта айырбастау"],
        "Enter amount": ["en": "Enter amount", "ru": "Введите сумму", "kk": "Соманы енгізіңіз"],
        "From": ["en": "From", "ru": "Из", "kk": "Бастапқы"],
        "To": ["en": "To", "ru": "В", "kk": "К"],
        "Converted Amount:": ["en": "Converted Amount:", "ru": "Конвертированная сумма:", "kk": "Айырбасталған сома:"],
        "Convert": ["en": "Convert", "ru": "Конвертировать", "kk": "Айырбастау"],
        "Refresh Rates": ["en": "Refresh Rates", "ru": "Обновить курсы", "kk": "Курстарды жаңарту"],
        "Fetching rates...": ["en": "Fetching rates...", "ru": "Получение курсов...", "kk": "Курстарды алу..."],
        "History": ["en": "History", "ru": "История", "kk": "Тарих"],
        "Clean": ["en": "Clean", "ru": "Очистить", "kk": "Тазалау"],
        "Settings": ["en": "Settings", "ru": "Настройки", "kk": "Параметрлер"],
        "Dark/Light Theme": ["en": "Dark/Light Theme", "ru": "Темная/Светлая тема", "kk": "Қара/Ашық тақырып"],
        "Bold Font": ["en": "Bold Font", "ru": "Жирный шрифт", "kk": "Қалың қаріп"],
        "API Key": ["en": "API Key", "ru": "API Ключ", "kk": "API Кілті"],
        "About Us": ["en": "About Us", "ru": "О нас", "kk": "Біз туралы"],
        "Language": ["en": "Language", "ru": "Язык", "kk": "Тіл"],
        "Theme Settings": ["en": "Theme Settings", "ru": "Настройки темы", "kk": "Тақырып параметрлері"],
        "Bold Font Settings": ["en": "Bold Font Settings", "ru": "Настройки жирного шрифта", "kk": "Қалың қаріп параметрлері"],
        "Enter your API Key": ["en": "Enter your API Key", "ru": "Введите ваш API Ключ", "kk": "API кілтіңізді енгізіңіз"],
        "Language Settings": ["en": "Language Settings", "ru": "Настройки языка", "kk": "Тіл параметрлері"],
        "Select Language": ["en": "Select Language", "ru": "Выберите язык", "kk": "Тілді таңдаңыз"],
        "Error": ["en": "Error", "ru": "Ошибка", "kk": "Қате"]
    ]
    return translations[key]?[lang] ?? key
}

// MARK: - ContentView
struct ContentView: View {
    // Состояния для конвертера
    @State private var amount: String = ""
    @State private var selectedCurrency: String = "USD"
    @State private var targetCurrency: String = "KZT"
    @State private var exchangeRates: [String: Double] = [:]
    @State private var lastUpdated: String = localized("Fetching rates...", lang: "en")
    @State private var convertedAmount: String = ""
    
    // Состояния для настроек
    @State private var isDarkMode: Bool = false
    @State private var isBoldFont: Bool = false
    @State private var apiKey: String = "6c67397d5840246afb5c487d" // Ваш API-ключ
    @State private var language: String = "en"  // "en", "ru" или "kk"
    
    // Состояния для обработки ошибок
    @State private var showAlert: Bool = false
    @State private var errorMessage: String = ""
    
    // Делегат истории
    @StateObject private var historyManager = HistoryManagerImpl()
    
    var body: some View {
        GeometryReader { geometry in
            TabView {
                // ConverterView – передаём необходимые биндинги и используем EnvironmentObject для истории
                ConverterView(
                    amount: $amount,
                    selectedCurrency: $selectedCurrency,
                    targetCurrency: $targetCurrency,
                    exchangeRates: $exchangeRates,
                    lastUpdated: $lastUpdated,
                    convertedAmount: $convertedAmount,
                    fetchExchangeRates: {
                        self.fetchExchangeRates()
                    },
                    isBoldFont: isBoldFont,
                    language: language
                )
                .tabItem {
                    Label(localized("Currency Converter", lang: language), systemImage: "arrow.right.arrow.left.circle")
                }
                
                // HistoryView – используем NavigationView и передаём делегата истории через environmentObject
                NavigationView {
                    HistoryView(isBoldFont: isBoldFont, language: language)
                }
                .tabItem {
                    Label(localized("History", lang: language), systemImage: "clock")
                }
                
                // SettingsView
                SettingsView(isDarkMode: $isDarkMode, isBoldFont: $isBoldFont, apiKey: $apiKey, language: $language)
                    .tabItem {
                        Label(localized("Settings", lang: language), systemImage: "gear")
                    }
            }
            .preferredColorScheme(isDarkMode ? .dark : .light)
            // Пример использования GeometryReader для отступов в зависимости от высоты экрана
            .padding(.vertical, geometry.size.height * 0.02)
            .onAppear {
                fetchExchangeRates()
            }
            .alert(isPresented: $showAlert) {
                Alert(title: Text(localized("Error", lang: language)), message: Text(errorMessage), dismissButton: .default(Text("OK")))
            }
            // Передаём делегата истории в дочерние представления
            .environmentObject(historyManager)
        }
    }
    
    // MARK: - Networking и обработка ошибок
    
    func fetchExchangeRates() {
        let urlStr: String
        if apiKey.isEmpty {
            urlStr = "https://api.exchangerate-api.com/v4/latest/USD"
        } else {
            urlStr = "https://v6.exchangerate-api.com/v6/\(apiKey)/latest/USD"
        }
        guard let url = URL(string: urlStr) else {
            showError("Invalid API URL")
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, _, error in
            if let error = error {
                showError("Error: \(error.localizedDescription)")
                return
            }
            
            guard let data = data else {
                showError("No data received")
                return
            }
            
            do {
                let decodedData = try JSONDecoder().decode(ExchangeRateResponse.self, from: data)
                DispatchQueue.main.async {
                                    exchangeRates = decodedData.conversion_rates
                                    let updated = DateFormatter.localizedString(from: Date(), dateStyle: .short, timeStyle: .short)
                                    withAnimation {
                                        lastUpdated = "Last updated: \(updated)"
                                    }
                                }
                            } catch {
                                showError("Decoding error: \(error.localizedDescription)")
                            }
                        }.resume()
                    }
                    
                    func showError(_ message: String) {
                        DispatchQueue.main.async {
                            errorMessage = message
                            showAlert = true
                        }
                    }
                }

                struct ExchangeRateResponse: Codable {
                    let conversion_rates: [String: Double]
                }

                // MARK: - ConverterView
struct ConverterView: View {
    @Binding var amount: String
    @Binding var selectedCurrency: String
    @Binding var targetCurrency: String
    @Binding var exchangeRates: [String: Double]
    @Binding var lastUpdated: String
    @Binding var convertedAmount: String
    var fetchExchangeRates: () -> Void
    var isBoldFont: Bool
    var language: String
    
    // Получаем делегата истории через EnvironmentObject
    @EnvironmentObject var historyManager: HistoryManagerImpl
    
    let currencies = ["KZT", "USD", "RUB", "EUR", "CNY"]
    
    var body: some View {
        VStack(spacing: 20) {
            Text(localized("Currency Converter", lang: language))
                .font(.largeTitle)
                .fontWeight(isBoldFont ? .bold : .regular)
                .foregroundColor(.primary)
                .padding()
                .transition(.slide)
            
            TextField(localized("Enter amount", lang: language), text: $amount)
                .keyboardType(.decimalPad)
                .padding()
                .background(RoundedRectangle(cornerRadius: 10).fill(Color(.systemGray6)))
                .padding(.horizontal)
            
            HStack {
                Picker(localized("From", lang: language), selection: $selectedCurrency) {
                    ForEach(currencies, id: \.self) { currency in
                        Text(currency)
                            .fontWeight(isBoldFont ? .bold : .regular)
                    }
                }
                .pickerStyle(MenuPickerStyle())
                .padding()
                .background(RoundedRectangle(cornerRadius: 10).fill(Color.blue.opacity(0.2)))
                
                Image(systemName: "arrow.right.arrow.left")
                    .font(.title)
                    .padding()
                
                Picker(localized("To", lang: language), selection: $targetCurrency) {
                    ForEach(currencies, id: \.self) { currency in
                        Text(currency)
                            .fontWeight(isBoldFont ? .bold : .regular)
                    }
                }
                .pickerStyle(MenuPickerStyle())
                .padding()
                .background(RoundedRectangle(cornerRadius: 10).fill(Color.blue.opacity(0.2)))
            }
            .padding(.horizontal)
            
            Text("\(localized("Converted Amount:", lang: language)) \(convertedAmount)")
                .font(.title2)
                .fontWeight(isBoldFont ? .bold : .regular)
                .padding()
                .animation(.easeIn, value: convertedAmount)
            
            Button(action: convert) {
                Text(localized("Convert", lang: language))
                    .font(.title2)
                    .fontWeight(isBoldFont ? .bold : .regular)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(LinearGradient(gradient: Gradient(colors: [Color.green, Color.blue]),
                                               startPoint: .leading,
                                               endPoint: .trailing))
                    .foregroundColor(.white)
                    .cornerRadius(12)
            }
            .padding(.horizontal)
            
            Spacer()
            
            Button(action: fetchExchangeRates) {
                Text(localized("Refresh Rates", lang: language))
                    .fontWeight(isBoldFont ? .bold : .regular)
                    .padding()
            }
            .foregroundColor(.blue)
            
            Text(lastUpdated)
                .font(.footnote)
                .fontWeight(isBoldFont ? .bold : .regular)
                .foregroundColor(.gray)
                .padding()
        }
    }
    
    func convert() {
        guard let amountDouble = Double(amount),
              let baseRate = exchangeRates[selectedCurrency],
              let targetRate = exchangeRates[targetCurrency] else { return }
        let result = amountDouble * (targetRate / baseRate)
        withAnimation {
                    convertedAmount = String(format: "%.2f", result)
                }
                let timestamp = DateFormatter.localizedString(from: Date(), dateStyle: .short, timeStyle: .short)
                // Добавляем запись в историю через делегата
                historyManager.addEntry( ("\(amount) \(selectedCurrency) -> \(convertedAmount) \(targetCurrency)", timestamp) )
            }
        }

        // MARK: - HistoryView

        struct HistoryView: View {
            var isBoldFont: Bool
            var language: String
            
            // Получаем историю через EnvironmentObject
            @EnvironmentObject var historyManager: HistoryManagerImpl
            
            var body: some View {
                List {
                    ForEach(historyManager.history, id: \.0) { entry in
                        VStack(alignment: .leading) {
                            Text(entry.0)
                                .font(.headline)
                                .fontWeight(isBoldFont ? .bold : .regular)
                            Text(entry.1)
                                .font(.subheadline)
                                .foregroundColor(.gray)
                                .fontWeight(isBoldFont ? .bold : .regular)
                        }
                    }
                    .onDelete(perform: deleteHistory)
                }
                .navigationTitle(localized("History", lang: language))
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) {
                        Button(localized("Clean", lang: language)) {
                            historyManager.clearHistory()
                        }
                    }
                    ToolbarItem(placement: .navigationBarTrailing) {
                        EditButton()
                    }
                }
            }
            
            func deleteHistory(at offsets: IndexSet) {
                historyManager.history.remove(atOffsets: offsets)
            }
        }

        // MARK: - SettingsView и дочерние представления

        struct SettingsView: View {
            @Binding var isDarkMode: Bool
            @Binding var isBoldFont: Bool
            @Binding var apiKey: String
            @Binding var language: String
            
            var body: some View {
                NavigationView {
                    Form {
                        Section(header: Text(localized("Appearance", lang: language))) {
                            NavigationLink(destination: ThemeSettingsView(isDarkMode: $isDarkMode, language: language)) {
                                Text(localized("Dark/Light Theme", lang: language))
                            }
                            NavigationLink(destination: BoldFontSettingsView(isBoldFont: $isBoldFont, language: language)) {
                                Text(localized("Bold Font", lang: language))
                            }
                        }
                        
                        Section(header: Text(localized("API Key", lang: language))) {
                            NavigationLink(destination: APIKeyView(apiKey: $apiKey, language: language)) {
                                Text(localized("API Key", lang: language))
                            }
                        }
                        
                        Section {
                            NavigationLink("About Us", destination: AboutUsView(language: language))
                        }
                        
                        Section(header: Text(localized("Language", lang: language))) {
                            NavigationLink(destination: LanguageSettingsView(language: $language)) {
                                Text(localized("Select Language", lang: language))
                            }
                        }
                    }
                    .navigationTitle(localized("Settings", lang: language))
                }
            }
        }

        struct ThemeSettingsView: View {
            @Binding var isDarkMode: Bool
            var language: String
            
            var body: some View {
                Form {
                    Toggle(localized("Dark/Light Theme", lang: language), isOn: $isDarkMode)
                }
                .navigationTitle(localized("Theme Settings", lang: language))
            }
        }

        struct BoldFontSettingsView: View {
            @Binding var isBoldFont: Bool
            var language: String
            
            var body: some View {
                Form {
                    Toggle(localized("Bold Font", lang: language), isOn: $isBoldFont)
                }
                .navigationTitle(localized("Bold Font Settings", lang: language))
            }
        }
struct APIKeyView: View {
    @Binding var apiKey: String
    var language: String
    
    var body: some View {
        Form {
            Section(header: Text(localized("Enter your API Key", lang: language))) {
                TextField("API Key", text: $apiKey)
                    .autocapitalization(.none)
                    .disableAutocorrection(true)
            }
        }
        .navigationTitle(localized("API Key", lang: language))
    }
}

struct AboutUsView: View {
    var language: String
    
    var body: some View {
        VStack(spacing: 20) {
            Text(localized("Sultanov Daniyar, Tazhibayev Sultanbay, Elik Shyngynkhan", lang: language))
                .multilineTextAlignment(.center)
                .padding()
            Spacer()
        }
        .padding()
        .navigationTitle(localized("About Us", lang: language))
    }
}

struct LanguageSettingsView: View {
    @Binding var language: String
    // Массив доступных языков с кодами
    let availableLanguages: [(name: String, code: String)] = [
        ("English", "en"),
        ("Русский", "ru"),
        ("Қазақша", "kk")
    ]
    
    var body: some View {
        Form {
            Section(header: Text(localized("Select Language", lang: language))) {
                Picker(localized("Language", lang: language), selection: $language) {
                    ForEach(availableLanguages, id: \.code) { lang in
                        Text(lang.name).tag(lang.code)
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
            }
        }
        .navigationTitle(localized("Language Settings", lang: language))
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
