import SwiftUI

struct ContentView: View {
    let characters: [String: String] = [
        "HP": "Harry Potter",
        "RH": "Ron Weasley",
        "HG": "Hermione Granger"
    ]
    
    @State private var characterList: [String] = ["Harry Potter", "Ron Weasley", "Hermione Granger"]
    @State private var characterToFind: String = ""
    @State private var foundCharacter: String = ""
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                Text("Character Management")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding(.top)
                
                SectionView(title: "Formatted character data:") {
                    ForEach(processCharacterData(data: characters) { key, value in
                        "\(key): \(value)"
                    }, id: \.self) { result in
                        Text(result)
                            .padding(5)
                            .cornerRadius(8)
                    }
                }
                
                Divider()
                    .padding(.horizontal)
                
                SectionView(title: "Character list:") {
                    VStack(spacing: 10) {
                        ForEach(characterList, id: \.self) { character in
                            Text(character)
                                .padding(5)
                                .cornerRadius(8)
                        }
                        HStack(spacing: 10) {
                            StyledButton(title: "Add Luna Lovegood", action: {
                                characterList.append("Luna Lovegood")
                                characterList.sort()
                            })
                            StyledButton(title: "Remove Hermione Granger", action: {
                                characterList.removeAll { $0 == "Hermione Granger" }
                            })
                        }
                    }
                }
                
                Divider()
                    .padding(.horizontal)
                
                SectionView(title: "Find character:") {
                    VStack(spacing: 15) {
                        TextField("Enter first and last name", text: $characterToFind)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .disableAutocorrection(true)
                        
                        StyledButton(title: "Find", action: {
                            if characterList.contains(characterToFind) {
                                foundCharacter = "\(characterToFind) is found!"
                            } else {
                                foundCharacter = "\(characterToFind) is not found."
                            }
                        })
                        
                        Text(foundCharacter)
                            .padding(8)
                            .background(foundCharacter.contains("not found") ? Color.red.opacity(0.2) : Color.green.opacity(0.2))
                            .cornerRadius(8)
                            .foregroundColor(foundCharacter.contains("not found") ? .red : .green)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
            }
            .padding(.bottom)
        }
    }
    
    func processCharacterData(data: [String: String], closure: (String, String) -> String) -> [String] {
        var results: [String] = []
        for (key, value) in data {
            results.append(closure(key, value))
        }
        return results
    }
}

struct SectionView<Content: View>: View {
    let title: String
    let content: Content
    
    init(title: String, @ViewBuilder content: () -> Content) {
        self.title = title
        self.content = content()
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title)
                .font(.headline)
                .padding(.bottom, 5)
            content
        }
        .padding()
        .background(Color.gray.opacity(0.1))
        .cornerRadius(10)
    }
}

struct StyledButton: View {
    let title: String
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.subheadline)
                .foregroundColor(.white)
                .padding(.horizontal, 10)
                .padding(.vertical, 5)
                .background(Color.blue)
                .cornerRadius(8)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
