//
//  Assighnment_6App.swift
//  Assighnment 6
//
//  Created by MacBook Air on 31.01.2025.
//

import SwiftUI

@main
struct Assighnment_6App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
